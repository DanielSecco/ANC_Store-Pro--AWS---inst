<div class="mkd-team-single-content">
	<?php the_content(); ?>
</div>