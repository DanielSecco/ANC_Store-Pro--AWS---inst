<?php

include_once MIKADO_CORE_SHORTCODES_PATH.'/pricing-item/functions.php';
include_once MIKADO_CORE_SHORTCODES_PATH.'/pricing-item/pricing-item.php';