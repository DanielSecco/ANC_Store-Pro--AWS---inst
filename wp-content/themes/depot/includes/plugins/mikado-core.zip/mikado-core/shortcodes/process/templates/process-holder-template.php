<div <?php depot_mikado_class_attribute($holder_classes); ?>>
	<div class="mkd-process-bg-holder"></div>
	<div class="mkd-process-inner">
		<?php echo do_shortcode($content); ?>
	</div>
</div>