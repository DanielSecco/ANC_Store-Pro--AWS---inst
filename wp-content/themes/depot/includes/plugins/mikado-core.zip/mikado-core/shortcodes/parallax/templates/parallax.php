<div class="mkd-parallax-holder <?php echo esc_attr($holder_class); ?>" <?php echo depot_mikado_get_inline_attrs($holder_data); ?> <?php echo depot_mikado_get_inline_style($holder_style); ?>>
	<div class="mkd-parallax-inner">
		<?php echo do_shortcode($content); ?>
	</div>
</div>
