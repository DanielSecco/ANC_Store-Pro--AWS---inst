<?php

include_once MIKADO_CORE_SHORTCODES_PATH.'/process/functions.php';
include_once MIKADO_CORE_SHORTCODES_PATH.'/process/process-holder.php';
include_once MIKADO_CORE_SHORTCODES_PATH.'/process/process-item.php';
