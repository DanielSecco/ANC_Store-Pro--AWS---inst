<div class="mkd-vss-ms-section" <?php echo depot_mikado_get_inline_attrs($content_data); ?> <?php depot_mikado_inline_style($content_style);?>>
	<?php echo do_shortcode($content); ?>
</div>